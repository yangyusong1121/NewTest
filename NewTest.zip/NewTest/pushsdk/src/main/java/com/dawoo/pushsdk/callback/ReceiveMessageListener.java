package com.dawoo.pushsdk.callback;

public interface ReceiveMessageListener {
    void onReceiveJson(String json);
}
