package com.nwf.user.newtest.net.rx;

public interface SubscriberOnNextListener<T> {
    void onNext(T t);
}
