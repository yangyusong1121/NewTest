package com.nwf.user.newtest;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.dawoo.ipc.control.IpcWebViewActivity;
import com.nwf.user.newtest.ipc.IPCSocketManager;
import com.nwf.user.newtest.mvp.presenter.TestPresenter;
import com.nwf.user.newtest.mvp.view.TestView;
import com.nwf.user.newtest.utils.SingleToast;

public class MainActivity extends AppCompatActivity implements TestView {

    TextView mTextView;
    TestPresenter mTestPresenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTestPresenter=new TestPresenter(this,this);
        mTestPresenter.getTest();
        IPCSocketManager.getInstance().connectTcpService();
        mTextView = findViewById(R.id.text);
        mTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, IpcWebViewActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString(ConstantValue.WEBVIEW_URL, "https://www.baidu.com/");
                intent.putExtras(bundle);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
               // mTestPresenter.getTest();
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mTestPresenter.onDestory();
        IPCSocketManager.getInstance().destroy();
    }

    @Override
    public void getPhoneNumber(Object O) {
        SingleToast.showMsg("回来了");
    }

}
