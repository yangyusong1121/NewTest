package com.nwf.user.newtest.mvp.service;

import com.nwf.user.newtest.bean.TestBean;

import retrofit2.http.GET;
import rx.Observable;

/**
 * Created by benson on 18-2-25.
 */

public interface ITestService {
    /**
     * 获取用户资产信息
     *
     * @return
     */
    @GET("/agreement/agreement/detail")
    Observable<TestBean> getUserAssert();
}
