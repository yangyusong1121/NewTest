package com.nwf.user.newtest.mvp.presenter;

import android.app.DatePickerDialog;
import android.content.Context;

import com.nwf.user.newtest.mvp.model.TestModel;
import com.nwf.user.newtest.mvp.view.IBaseView;
import com.nwf.user.newtest.mvp.view.TestView;
import com.nwf.user.newtest.net.rx.ProgressSubscriber;

import rx.Subscription;


/**
 * 我的页面presenter
 */

public class TestPresenter<T extends IBaseView> extends BasePresenter {

    private final Context mContext;
    private T mView;
    private final TestModel mMineModel;
    private DatePickerDialog mDialog;

    public TestPresenter(Context context, T mView) {
        super(context, mView);
        mContext = context;
        this.mView = mView;
        mMineModel = new TestModel();
    }

    public void getTest(){
        Subscription subscription = mMineModel.getTetst(new ProgressSubscriber<>(o -> ((TestView) mView).getPhoneNumber(o), mContext));
        subList.add(subscription);
    }

    @Override
    public void onDestory() {
        super.onDestory();
    }
}
