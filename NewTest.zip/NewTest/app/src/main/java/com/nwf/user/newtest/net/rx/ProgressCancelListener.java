package com.nwf.user.newtest.net.rx;

public interface ProgressCancelListener {
    void onCancelProgress();
}
