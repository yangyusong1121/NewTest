package com.nwf.user.newtest.mvp.view;

/**
 * Created by benson on 17-12-21.
 */

public interface IBaseView {

}
