package com.nwf.user.newtest.mvp.model;

import com.nwf.user.newtest.bean.TestBean;
import com.nwf.user.newtest.mvp.service.ITestService;
import com.nwf.user.newtest.net.RetrofitHelper;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;

public class TestModel extends BaseModel{


    public void getTetst(){

    }
    public Subscription getTetst(Subscriber subscriber) {
        Observable<TestBean> observable = RetrofitHelper.getService(ITestService.class).getUserAssert();
        return toSubscribe(observable, subscriber);
    }
}
