package com.nwf.user.newtest.mvp.view;

public interface TestView extends IBaseView {
    void getPhoneNumber(Object O);
}
