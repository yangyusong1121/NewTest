package com.dawoo.ipc.event.bean;

/**
 * archar  天纵神武
 **/
public class BaseIpcEvent {
    protected String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
